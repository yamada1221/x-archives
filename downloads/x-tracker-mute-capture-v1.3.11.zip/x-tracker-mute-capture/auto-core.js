'use strict';
(function (root) {
  const MINUTE = 60000, HOUR = 60 * MINUTE, DAY = 24 * HOUR;
  const DEFAULT_PROVIDER = 'archive.today';
  const ARCHIVE_HOSTS = ['archive.li', 'archive.md', 'archive.ph', 'archive.is', 'archive.today', 'archive.vn', 'archive.fo'];
  const ADAPTERS = { 'archive.today': 'archive-today-dom-3', ghostarchive: 'ghostarchive-dom-1' };
  const ADAPTER_VERSION = ADAPTERS[DEFAULT_PROVIDER];
  const provider = value => value === 'archive.li' ? DEFAULT_PROVIDER : value || DEFAULT_PROVIDER;
  const adapterVersion = value => Object.hasOwn(ADAPTERS, provider(value)) ? ADAPTERS[provider(value)] : '';
  const providerLabel = value => provider(value) === DEFAULT_PROVIDER ? 'archive.li' : 'Ghostarchive';
  const homeURL = value => provider(value) === DEFAULT_PROVIDER ? 'https://archive.li/' : 'https://ghostarchive.org/';
  const origins = value => ['https://api.github.com/*', 'https://api.fxtwitter.com/*',
    ...(provider(value) === DEFAULT_PROVIDER ? ARCHIVE_HOSTS.map(h => 'https://' + h + '/*') : ['https://ghostarchive.org/*'])];
  const LABELS = { queued: '保存待ち', opening: '保存先を準備中', submitting: '保存依頼中', processing: '保存処理中',
    verifying: '内容確認中', succeeded: '保存済み', retry_wait: '再試行待ち', submission_unknown: '受付結果不明',
    needs_review: '手動確認が必要', canceled: '中止', skipped: '対象外' };
  const TERMINAL = new Set(['succeeded', 'canceled', 'skipped', 'needs_review']);
  const UNKNOWN_RECEIPT_ERRORS = new Set(['受付結果が不明です。保存先の画面または検索結果で確認してください',
    '受付URLを確認できません。保存先の画面で確認してください', '受付URLを確認できません。保存先の検索結果から結果URLを指定してください']);
  const attention = job => ['needs_review', 'submission_unknown'].includes(job.state) || Boolean(job.access_wait);
  const jobLabel = job => job.access_wait === 'human' ? '人間確認待ち' : job.access_wait ? 'アクセス制限の解除待ち' : LABELS[job.state];
  const submissionHold = (jobs, selected) => jobs.some(j => (j.provider || 'ghostarchive') === selected &&
    !['succeeded', 'canceled', 'skipped'].includes(j.state) && (j.access_wait || j.receipt_recovery_required ||
      j.state === 'needs_review' && j.submission_started_at && !j.receipt && UNKNOWN_RECEIPT_ERRORS.has(j.last_error)));
  const norm = s => String(s ?? '').replace(/\s+/g, ' ').trim();
  const handle = s => typeof s === 'string' && /^[A-Za-z0-9_]{1,15}$/.test(s) &&
    !/^(home|search|settings|i|intent|login|logout|explore|messages|notifications)$/i.test(s);
  function config(value = {}) {
    const v = { owner: 'yamada1221', repo: 'x-archives', path: 'data/artists.json', ...value };
    if (!/^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/.test(v.owner) || !/^[A-Za-z0-9_.-]{1,100}$/.test(v.repo)) throw Error('GitHubのownerとrepoを確認してください');
    if (typeof v.path !== 'string' || !/^(?:[A-Za-z0-9_.-]+\/)*[A-Za-z0-9_.-]+\.json$/.test(v.path) || v.path.split('/').some(p => p === '.' || p === '..')) throw Error('データファイルのパスを確認してください');
    if (typeof v.token !== 'string' || !v.token.trim() || /[\s\r\n]/.test(v.token) || v.token.length > 300) throw Error('Fine-grained PATを入力してください');
    if (!adapterVersion(v.provider)) throw Error('保存先を確認してください');
    return { owner: v.owner, repo: v.repo, path: v.path, token: v.token, enabled: v.enabled === true,
      provider: provider(v.provider), providerReady: v.providerReady || '', nextScanAt: Number(v.nextScanAt) || 0 };
  }
  const scope = c => `${c.owner.toLowerCase()}/${c.repo.toLowerCase()}:${c.path}`;
  function profileURL(value) {
    try {
      const u = new URL(value);
      if (u.protocol !== 'https:' || u.username || u.password || u.port || !['x.com', 'twitter.com', 'www.x.com', 'www.twitter.com'].includes(u.hostname)) return '';
      const h = u.pathname.replace(/^\//, '').replace(/\/$/, '');
      return handle(h) ? 'https://x.com/' + h.toLowerCase() : '';
    } catch (_) { return ''; }
  }
  function targetURL(value) {
    try {
      const u = new URL(value);
      if (u.protocol !== 'https:' || u.username || u.password || u.port || !['x.com', 'twitter.com', 'www.x.com', 'www.twitter.com'].includes(u.hostname)) return '';
      const match = u.pathname.match(/^\/([A-Za-z0-9_]{1,15})(\/with_replies)?\/?$/i);
      return match && handle(match[1]) ? 'https://x.com/' + match[1].toLowerCase() + (match[2] ? '/with_replies' : '') : '';
    } catch (_) { return ''; }
  }
  function targetCovers(requested, captured) {
    const target = targetURL(requested), actual = targetURL(captured);
    return Boolean(target && actual && (target === actual ||
      !target.endsWith('/with_replies') && actual === target + '/with_replies'));
  }
  const repliesTagged = a => String(a?.note || '').split(/[\s/、,，]+/u).includes('クソリプ');
  function searchTarget(value) {
    try {
      const u = new URL(value);
      if (u.protocol !== 'https:' || u.port || u.username || u.password) return '';
      if (ARCHIVE_HOSTS.includes(u.hostname)) return targetURL(decodeURIComponent(u.pathname.slice(1)));
      if (u.hostname === 'ghostarchive.org' && u.pathname === '/search') return targetURL(u.searchParams.get('term'));
      return '';
    } catch (_) { return ''; }
  }
  function resultURL(value) {
    try {
      const u = new URL(value);
      if (u.protocol !== 'https:' || u.username || u.password || u.port) return '';
      if (u.hostname === 'ghostarchive.org' && /^\/archive\/[A-Za-z0-9]+\/?$/.test(u.pathname)) return u.origin + u.pathname.replace(/\/$/, '');
      if (ARCHIVE_HOSTS.includes(u.hostname) && (/^\/[A-Za-z0-9]{5}\/?$/.test(u.pathname) && u.pathname.replace(/\/$/, '') !== '/about' ||
          /^\/wip\/(?:[A-Za-z0-9]+|\d{4}\.\d{2}\.\d{2}-\d{6}(?:\/https?:\/\/.+)?)\/?$/.test(u.pathname) ||
          /^\/(?:\d{8,14}|\d{4}\.\d{2}\.\d{2}-\d{6})\/https?:\/\/.+/.test(u.pathname))) return u.origin + u.pathname.replace(/\/$/, '');
      return '';
    }
    catch (_) { return ''; }
  }
  const resultProvider = value => { const url = resultURL(value); return !url ? '' : new URL(url).hostname === 'ghostarchive.org' ? 'ghostarchive' : DEFAULT_PROVIDER; };
  const processingURL = value => Boolean(resultURL(value) && new URL(value).pathname.startsWith('/wip/'));
  const receiptTransition = (from, to) => Boolean(resultURL(from) && resultURL(to) && resultProvider(from) === DEFAULT_PROVIDER && resultProvider(to) === DEFAULT_PROVIDER &&
    (processingURL(from) && !processingURL(to) || new URL(from).pathname === new URL(to).pathname));
  function eligible(a, selected = DEFAULT_PROVIDER) {
    if (!a || typeof a.id !== 'string' || !handle(a.x_account) || a.tracking_mode !== 'record') return false;
    const c = a.auto_archive || {};
    return c.enabled !== 'off' && c.enabled !== false && (!c.policy || c.policy === 'first_only') &&
      (!c.target || c.target === 'profile') && (!c.provider || c.provider === 'inherit' || provider(c.provider) === provider(selected));
  }
  function completed(a, target = 'profile') {
    if (target === 'replies') return (a.archives || []).some(e => e?.status === 'done' &&
      targetURL(e.target_url) === targetURL('https://x.com/' + a.x_account + '/with_replies') &&
      (!Array.isArray(e.verified_scope) || e.verified_scope.includes('replies')));
    // Preserve legacy registrations without claiming that they passed new verification.
    return Boolean(a.archive_status === 'done' && a.archive_url && !targetURL(a.archive_target_url).endsWith('/with_replies')) ||
      (a.archives || []).some(e => e?.status === 'done' && (Array.isArray(e.verified_scope) ?
        e.verified_scope.includes('profile') && targetCovers('https://x.com/' + a.x_account, e.target_url) :
        !targetURL(e.target_url).endsWith('/with_replies')));
  }
  function sameAccount(a, job) {
    if (!a || a.id !== job.artist_id || !eligible(a, job.provider || 'ghostarchive')) return false;
    if (job.target_kind === 'replies' && !repliesTagged(a)) return false;
    if (job.expected_x_user_id && a.x_user_id) return a.x_user_id === job.expected_x_user_id;
    return a.x_account.toLowerCase() === job.registered_handle.toLowerCase();
  }
  function classifyProfile(payload, status, username, id = '') {
    if (status !== 200 || payload?.code !== 200 || payload.reason || !payload.user) throw Error('プロフィール取得は判定不能です');
    const u = payload.user;
    if (typeof u.id !== 'string' || !/^\d+$/.test(u.id) || !handle(u.screen_name)) throw Error('プロフィールの数値IDを確認できません');
    if (id ? id !== u.id : u.screen_name.toLowerCase() !== username.toLowerCase()) throw Error('アカウントの数値ID・ユーザー名が一致しません');
    if (u.protected === true) throw Error('非公開アカウントのため保存を待機しています');
    return { id: u.id, handle: u.screen_name, name: typeof u.name === 'string' ? u.name : '', bio: typeof u.description === 'string' ? u.description : null };
  }
  function validateArtists(doc) {
    if (!doc || !Array.isArray(doc.artists)) throw Error('アカウント一覧の形式が正しくありません');
    const ids = new Set();
    for (const a of doc.artists) {
      if (!a || typeof a.id !== 'string' || !a.id || ids.has(a.id)) throw Error('アカウントIDが不正・重複しています');
      ids.add(a.id);
      if (a.x_user_id != null && (typeof a.x_user_id !== 'string' || !/^\d+$/.test(a.x_user_id))) throw Error('数値ユーザーIDは文字列で保存してください');
      if (a.archives != null && !Array.isArray(a.archives)) throw Error('アーカイブ履歴の形式が正しくありません');
    }
    return doc;
  }
  function ledger(doc) {
    if (!doc) return { version: 1, jobs: [], reservations: [], provider: {} };
    if (doc.version !== 1 || !Array.isArray(doc.jobs) || !Array.isArray(doc.reservations) || !doc.provider) throw Error('共有ジョブ台帳の形式が正しくありません');
    const ids = new Set();
    for (const j of doc.jobs) {
      if (!j || typeof j.job_id !== 'string' || ids.has(j.job_id) || !LABELS[j.state]) throw Error('共有ジョブの形式が正しくありません');
      if (j.receipt && !resultURL(j.receipt)) throw Error('共有ジョブの保存結果URLが不正です');
      if (j.provider && !Object.hasOwn(ADAPTERS, j.provider)) throw Error('共有ジョブの保存先が不正です');
      if (j.receipt && resultProvider(j.receipt) !== (j.provider || 'ghostarchive')) throw Error('共有ジョブの保存先と結果URLが一致しません');
      if (j.receipt) j.receipt = resultURL(j.receipt);
      if (j.target_url && !targetURL(j.target_url)) throw Error('共有ジョブの対象URLが不正です');
      if (j.target_url && targetURL(j.target_url).endsWith('/with_replies') !== (j.target_kind === 'replies')) throw Error('共有ジョブの保存対象が一致しません');
      if (j.expected_x_user_id && (typeof j.expected_x_user_id !== 'string' || !/^\d+$/.test(j.expected_x_user_id))) throw Error('共有ジョブの数値IDが不正です');
      ids.add(j.job_id);
    }
    return doc;
  }
  function verify(outer, frames, job, now) {
    const requested = targetURL(job.target_url), captured = targetURL(outer?.original_url);
    if (!requested) return { ok: false, reason: '保存対象のURLを確認できません' };
    if (!captured) return { ok: false, reason: '保存先の対象URLを確認できません' };
    if (!targetCovers(requested, captured)) {
      if (captured.replace(/\/with_replies$/, '') !== requested.replace(/\/with_replies$/, '')) return { ok: false, reason: '保存先の対象アカウントが一致しません' };
      return { ok: false, reason: '保存先はプロフィールです。返信タブの保存結果を選んでください' };
    }
    if (requested.endsWith('/with_replies') !== (job.target_kind === 'replies')) return { ok: false, reason: '保存対象の種類が一致しません' };
    const stamp = Date.parse(outer.captured_at);
    if (!Number.isFinite(stamp) || stamp > now + 5 * MINUTE) return { ok: false, reason: '保存先の取得時刻を確認できません' };
    const p = frames.find(f => f.kind === 'profile' && f.handle?.toLowerCase() === job.identity?.handle.toLowerCase());
    if (!p || !p.following || !p.name) return { ok: false, reason: 'プロフィール本文・対象ハンドルを確認できません' };
    if (job.target_kind === 'replies' && !p.replies_tab_confirmed) return { ok: false, reason: '返信タブの本文を確認できません' };
    if (p.user_id && p.user_id !== job.expected_x_user_id) return { ok: false, reason: '保存本文の数値IDが別のアカウントです' };
    if (!p.user_id && (!job.identity || norm(p.name) !== norm(job.identity.name) || job.identity.bio === null || norm(p.bio) !== norm(job.identity.bio))) {
      return { ok: false, reason: '本文から同じアカウントだと確認する証拠が不足しています' };
    }
    const reused = Boolean(job.adopted_existing) || stamp < Date.parse(job.submission_started_at) - 5 * MINUTE;
    if (reused && !p.user_id) return { ok: false, reason: '過去の保存を採用するには、保存本文の数値IDによる照合が必要です' };
    return { ok: true, captured_at: new Date(stamp).toISOString(), verified_at: new Date(now).toISOString(),
      method: 'archived_profile_body', captured_target_url: captured,
      scope: captured.endsWith('/with_replies') && p.replies_tab_confirmed ? ['profile', 'replies'] : ['profile'],
      posts_verification: p.post_ids?.length ? 'confirmed' : 'unconfirmed',
      post_ids: (p.post_ids || []).slice(0, 20), archived_user_id: p.user_id || '', reused_existing: reused };
  }
  function applyResult(doc, job) {
    validateArtists(doc);
    const a = doc.artists.find(a => a.id === job.artist_id);
    if (!sameAccount(a, job)) return false;
    const actualTarget = job.verification?.captured_target_url === undefined ? targetURL(job.target_url) : targetURL(job.verification.captured_target_url);
    const hadPrimary = Boolean(a.archive_status === 'done' && a.archive_url);
    const e = { provider: resultProvider(job.receipt), url: resultURL(job.receipt), target_url: actualTarget,
      requested_target_url: job.target_url, status: 'done',
      job_id: job.job_id, event_key: job.event_key, x_user_id: job.expected_x_user_id, requested_at: job.adopted_existing ? null : job.submission_started_at,
      captured_at: job.verification.captured_at, saved_at: job.verification.verified_at, content_verified_at: job.verification.verified_at,
      verification_method: job.verification.method, verified_scope: job.verification.scope, posts_verification: job.verification.posts_verification,
      reused_existing: job.verification.reused_existing };
    if (!e.url || processingURL(e.url) || e.provider !== (job.provider || 'ghostarchive') || !job.verification.ok ||
        !targetCovers(job.target_url, actualTarget)) throw Error('未検証の結果は保存済みにできません');
    const sameCapture = (a.archives || []).filter(p => p?.status === 'done' && resultURL(p.url) === e.url &&
      (p.x_user_id ? p.x_user_id === e.x_user_id :
        targetURL(p.target_url).replace(/\/with_replies$/, '') === actualTarget.replace(/\/with_replies$/, '')));
    const scopes = new Set([...(e.verified_scope || []), ...sameCapture.flatMap(p => p.verified_scope || [])]);
    e.verified_scope = ['profile', 'replies'].filter(value => scopes.has(value));
    a.archives = [...(a.archives || []).filter(p => p.url !== e.url), e];
    if (e.verified_scope.includes('profile') && (!actualTarget.endsWith('/with_replies') || !hadPrimary)) {
      a.archive_status = 'done'; a.archive_url = e.url; a.archive_provider = e.provider;
      a.archive_target_url = e.target_url; a.archive_checked_at = e.content_verified_at;
    }
    if (!a.x_user_id) a.x_user_id = job.expected_x_user_id;
    delete a.archive_error;
    return true;
  }
  const api = { MINUTE, HOUR, DAY, DEFAULT_PROVIDER, ARCHIVE_HOSTS, ADAPTERS, ADAPTER_VERSION, provider, adapterVersion, providerLabel, homeURL, origins,
    LABELS, TERMINAL, UNKNOWN_RECEIPT_ERRORS, attention, jobLabel, submissionHold, norm, handle, config, scope, profileURL, targetURL, targetCovers, repliesTagged, searchTarget, resultURL, resultProvider, processingURL, receiptTransition,
    eligible, completed, sameAccount, classifyProfile, validateArtists, ledger, verify, applyResult };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.AutoArchiveCore = api;
})(globalThis);
